//Ham menu nho lai
function toggleMenu() {
  const menu = document.getElementById("nav-menu");
  if (menu) {
    menu.classList.toggle("active");
  } else {
    console.log("Không tìm thấy phần tử có id='nav-menu'");
  }
}
//Button back home ne
document.getElementById("scrollTopButton").onclick = function () {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
};
